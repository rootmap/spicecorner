<footer id="footer">
    <div class="container brd1">
        <div class="row">
            <div class="grid_6">
                <div class="info" style="text-align:left;">
                    
                    Design &amp; Developed By 
                    <a target="_blank" href="http://digimo.se/">Digimo</a>
                    <!-- {%FOOTER_LINK} -->
                </div>
            </div>
            <div class="grid_6">
                <div class="info" style="text-align:right;">
                    <a class="text_900" href="./">Spice Corner</a>
                    ©
                    <span id="copyright-year"></span>
                    .
                    <a href="{{url('privacy')}}">Privacy Policy</a>
                    <!-- {%FOOTER_LINK} -->
                </div>
            </div>
        </div>
    </div>
</footer>